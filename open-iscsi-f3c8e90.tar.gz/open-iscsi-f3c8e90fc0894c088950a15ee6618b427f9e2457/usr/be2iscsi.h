#ifndef BE2ISCSI_TRANSPORT
#define BE2ISCSI_TRANSPORT

struct iscsi_conn;

extern void be2iscsi_create_conn(struct iscsi_conn *conn);

#endif
